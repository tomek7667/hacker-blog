
from __future__ import annotations

import io
import json
from functools import lru_cache

from PIL import Image

from .paths import ROOM_DIR

TILE = 16
ANIMATED_DIR = ROOM_DIR / "animated"
MANIFEST_FILE = ANIMATED_DIR / "animated.json"
SHEET_ID = "animated"

_manifest: dict | None = None


def manifest() -> dict:
    global _manifest
    if _manifest is None:
        try:
            _manifest = json.loads(MANIFEST_FILE.read_text())
        except (OSError, ValueError):
            _manifest = {"tile": TILE, "sheets": {}}
    return _manifest


def sheets() -> dict[str, dict]:
    return manifest().get("sheets", {})


def sheet_path(sheet: str):
    if sheet not in sheets():
        return None
    path = (ANIMATED_DIR / sheet).resolve()
    return path if path.parent == ANIMATED_DIR.resolve() and path.is_file() else None


@lru_cache(maxsize=4096)
def slice_cell(sheet: str, col: int, row: int, frame: int = 0) -> bytes:
    info = sheets().get(sheet)
    path = sheet_path(sheet)
    if info is None or path is None:
        raise FileNotFoundError(sheet)
    if not (0 <= frame < info["frames"]):
        raise ValueError("frame out of range")
    if not (0 <= col < info["fw"] // TILE and 0 <= row < info["fh"] // TILE):
        raise ValueError("cell out of range")
    x = frame * info["fw"] + col * TILE
    y = row * TILE
    with Image.open(path) as im:
        cell = im.convert("RGBA").crop((x, y, x + TILE, y + TILE))
    buf = io.BytesIO()
    cell.save(buf, format="PNG")
    return buf.getvalue()
